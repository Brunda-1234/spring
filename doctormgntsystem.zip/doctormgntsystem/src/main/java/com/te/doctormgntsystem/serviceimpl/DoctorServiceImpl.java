package com.te.doctormgntsystem.serviceimpl;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.te.doctormgntsystem.ImageCD;
import com.te.doctormgntsystem.dto.BookingAppointmentDto;
import com.te.doctormgntsystem.entity.Appointment;
import com.te.doctormgntsystem.entity.Doctor;
import com.te.doctormgntsystem.exception.DoctorNotFoundException;
import com.te.doctormgntsystem.repository.AppointmentRepository;
import com.te.doctormgntsystem.repository.DoctorRepository;
import com.te.doctormgntsystem.service.DoctorService;

@Service
public class DoctorServiceImpl implements DoctorService {

	@Autowired
	private DoctorRepository doctorRepository;
	@Autowired
	private AppointmentRepository appointmentRepository;

	@Override
	public List<BookingAppointmentDto> allAppointments(Integer doctorId) {

		try {
			Doctor doctor = doctorRepository.findById(doctorId)
					.orElseThrow(() -> new DoctorNotFoundException("Doctor Not Found"));
			List<Appointment> appointments = doctor.getAppointments();
			List<BookingAppointmentDto> list = new ArrayList<>();
			appointments.stream().forEach(i -> {
				BookingAppointmentDto bookingAppointmentDto = new BookingAppointmentDto();

				bookingAppointmentDto.setLocalDateTime(i.getLocalDateTime());
				bookingAppointmentDto.setDoctorId(i.getDoctor().getDoctorId());
				bookingAppointmentDto.setId(i.getUser().getId());
				list.add(bookingAppointmentDto);

			});

			return list;
		} catch (DoctorNotFoundException e) {
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw new DoctorNotFoundException("Something Went Wrong in Doctor");
		}
	}

}

