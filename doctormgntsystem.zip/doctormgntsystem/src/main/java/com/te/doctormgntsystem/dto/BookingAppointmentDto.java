package com.te.doctormgntsystem.dto;

import java.time.LocalDateTime;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class BookingAppointmentDto {

	@JsonFormat(pattern = "yyyy-MM-dd-HH-mm", shape = Shape.STRING)
	private LocalDateTime localDateTime;
	
	
	private Integer id;
	private Integer doctorId;

}
