package com.te.doctormgntsystem.exception;

import org.springframework.security.access.AccessDeniedException;

@SuppressWarnings("serial")
public class InvalidTokenException extends AccessDeniedException{

	public InvalidTokenException(String message) {
		super(message);
	}
}
