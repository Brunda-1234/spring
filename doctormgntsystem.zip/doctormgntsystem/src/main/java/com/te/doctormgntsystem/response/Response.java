package com.te.doctormgntsystem.response;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.te.doctormgntsystem.dto.DoctorDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Component
public class Response {

	private boolean error;
	private String message;
	private HttpStatus status;
	private Object data;
	
}
