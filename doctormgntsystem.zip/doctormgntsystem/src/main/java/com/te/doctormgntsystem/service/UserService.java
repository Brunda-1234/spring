package com.te.doctormgntsystem.service;

import java.io.IOException;
import java.util.List;
import java.util.zip.DataFormatException;

import com.te.doctormgntsystem.dto.BookingAppointmentDto;
import com.te.doctormgntsystem.dto.DoctorDto;
import com.te.doctormgntsystem.dto.DoctorOneDto;
import com.te.doctormgntsystem.dto.DoctorRatingDto;
import com.te.doctormgntsystem.entity.Appointment;
import com.te.doctormgntsystem.entity.Doctor;
import com.te.doctormgntsystem.entity.DoctorRating;

public interface UserService {

//	List<DoctorOneDto> getDoctors(String doctorPhoneNumber);
//	List<DoctorOneDto> getDoctor( String fileName,String doctorPhoneNumber) throws IOException, DataFormatException;

	public List<DoctorOneDto> getAllDoctorList();


	public String bookingAppointment(BookingAppointmentDto bookingAppointmentDto);

	public String updateRatings(DoctorRatingDto doctorRatingDto);

	List<DoctorOneDto> getDoctor(String doctorPhoneNumber);

	

}
