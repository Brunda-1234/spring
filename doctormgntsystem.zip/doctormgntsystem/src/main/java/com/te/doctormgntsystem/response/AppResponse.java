package com.te.doctormgntsystem.response;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Component
public class AppResponse {

	private boolean error;
	private String message;
	private HttpStatus status;
	private Map<String, String> token;
	
	
}
