package com.te.doctormgntsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.doctormgntsystem.dto.BookingAppointmentDto;
import com.te.doctormgntsystem.dto.DoctorRatingDto;
import com.te.doctormgntsystem.response.Response;
import com.te.doctormgntsystem.service.UserService;

@RestController
@RequestMapping("/user/")
public class UserController {

	@Autowired
	private UserService userService;

	@PreAuthorize("hasRole('ROLE_USER')")
	@GetMapping("get/doctor/{doctorPhoneNumber}")
	public ResponseEntity<Response> serachByDoctorNumber(@PathVariable String doctorPhoneNumber) {
		return ResponseEntity.accepted().body(new Response(false, "Data Fetched Successfully", HttpStatus.ACCEPTED,
				userService.getDoctor(doctorPhoneNumber)));
	}

	@PreAuthorize("hasRole('ROLE_USER')")
	@GetMapping("getAll/doctor")
	public ResponseEntity<Response> getAllDoctors() {
		return ResponseEntity.accepted().body(
				new Response(false, "Data Fetched Successfully", HttpStatus.ACCEPTED, userService.getAllDoctorList()));
	}

	@PreAuthorize("hasRole('ROLE_USER')")
	@PostMapping("book/appointments")
	public ResponseEntity<Response> booking(@RequestBody BookingAppointmentDto appointmentDto) {
		return ResponseEntity.accepted().body(new Response(false, "Booking Successfull", HttpStatus.ACCEPTED,
				userService.bookingAppointment(appointmentDto)));
	}

	@PreAuthorize("hasRole('ROLE_USER')")
	@PutMapping("update/doctor/rating")
	public ResponseEntity<Response> ratings(@RequestBody DoctorRatingDto doctorRatingDto) {

		return ResponseEntity.accepted().body(new Response(false, "Doctor updated Successfully", HttpStatus.ACCEPTED,
				userService.updateRatings(doctorRatingDto)));
	}

}
