package com.te.doctormgntsystem.entity;

public enum DoctorSpecialization {
	
	CARDIAC_SURGEON,
	HEART_SPECIALIST,
	NEUROLOGIST,
	ORTHOPEDICS,
	GENERAL_SURGEON,
	

}
