package com.te.doctormgntsystem.jwtfilter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	private final JwtTokenGeneration jwtTokenGeneration;

	private final UserDetailsService userDetailsService;

	@Override
	protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response,
			@NonNull FilterChain filterChain)
			/*
			 * A FilterChain is an object provided by the servlet container to the developer
			 * giving a view into the invocation chain of a filtered request for a resource.
			 * Filters use the FilterChain to invoke the next filter in the chain
			 */
			throws ServletException, IOException {

		System.err.println("doFilter");

		final String authHeader = request.getHeader("Authorization");
		/*
		 * the JWT (JSON Web Token)  the authHeader variable after it is
		 * extracted from the "Authorization" header of the HTTP request.
		 */
		final String jwt;
		final String userEmail;
		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
			filterChain.doFilter(request, response);

			/*
			 * filterchain is an interface Causes the next filter in the chain to be
			 * invoked, or if the calling filter is the last filter in the chain, causes the
			 * resource at the end of the chain to be invoked.
			 */
			return;
		}
		jwt = authHeader.substring(7);
		userEmail = jwtTokenGeneration.extractUsername(jwt);

		System.err.println(userEmail.toString());

		// validating the token here
		if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {
			UserDetails userDetails = this.userDetailsService.loadUserByUsername(userEmail);
			System.err.println(userDetails.toString());
			// UserDetails means AppUserData
			

			// after getting the appuserdata
			/*
			 * The isTokenvalidate method likely performs checks such as verifying the
			 * signature, expiration, and integrity of the JWT, as well as comparing it
			 * against the user details to ensure it corresponds to a valid and authorized
			 * user.
			 */

			if (jwtTokenGeneration.isTokenValid(jwt, userDetails)) {

				UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());
				System.err.println(authenticationToken.toString());

				authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

				SecurityContextHolder.getContext().setAuthentication(authenticationToken);

			}
			/*
			 * If the token is valid, a new UsernamePasswordAuthenticationToken is created
			 * using the UserDetails, 4 with null credentials and the user's authorities.
			 */

			/*
			 * The request(get all data,getAllAppointmets ,etc) details are populated into
			 * the authenticationToken using WebAuthenticationDetailsSource.
			 */

			/*
			 * Finally, the validated and authenticated authenticationToken is set in the
			 * SecurityContextHolder to establish the authenticated context for the request.
			 */
		}
		filterChain.doFilter(request, response);
	}

}
