package com.te.doctormgntsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.doctormgntsystem.dto.RefreshTokenDto;
import com.te.doctormgntsystem.jwtfilter.JwtTokenGeneration;
import com.te.doctormgntsystem.response.AccessResponse;
import com.te.doctormgntsystem.service.RegenerateTokenService;

@RestController
@RequestMapping("/authcontrol")
public class TokenController {
	
	@Autowired
	private JwtTokenGeneration jwtTokenGeneration;
	@Autowired
	private UserDetailsService userDetailsService;
	@Autowired
	private RegenerateTokenService regenerateTokenService;
	
	 
	@PostMapping("/api/generate/accesstoken")
	public ResponseEntity<AccessResponse> newAccessTokenGeneration(@RequestBody RefreshTokenDto refreshTokenDto){
		
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(new AccessResponse(false, HttpStatus.ACCEPTED, "SuccessFully Generated New AccessToken Using The Refresh token ", regenerateTokenService.generateNewAccessToken(refreshTokenDto)));
		
	}
}
