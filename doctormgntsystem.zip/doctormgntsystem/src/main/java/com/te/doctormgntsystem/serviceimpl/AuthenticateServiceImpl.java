package com.te.doctormgntsystem.serviceimpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.te.doctormgntsystem.dto.DoctorDto;
import com.te.doctormgntsystem.dto.LoginDto;
import com.te.doctormgntsystem.dto.UserDto;
import com.te.doctormgntsystem.entity.AppUser;
import com.te.doctormgntsystem.entity.Doctor;
import com.te.doctormgntsystem.entity.Role;
import com.te.doctormgntsystem.entity.User;
import com.te.doctormgntsystem.exception.AuthenticationException;
import com.te.doctormgntsystem.exception.DoctorAlreadyExistsException;
import com.te.doctormgntsystem.exception.UserAlreadyExistsException;
import com.te.doctormgntsystem.jwtfilter.JwtTokenGeneration;
import com.te.doctormgntsystem.repository.AppUserRepository;
import com.te.doctormgntsystem.repository.DoctorRepository;
import com.te.doctormgntsystem.repository.UserRepository;
import com.te.doctormgntsystem.response.AuthResponse;
import com.te.doctormgntsystem.service.AuthenticateService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthenticateServiceImpl implements AuthenticateService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private DoctorRepository doctorRepository;
	@Autowired
	private AppUserRepository appUserRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private JwtTokenGeneration tokenGeneration;
	@Autowired
	private AuthenticationManager authenticationManager;

	@Override
	public UserDto registerUser(UserDto userDto) {

		User user = new User();
		if (user.getEmail() == userDto.getEmail()) {
			throw new UserAlreadyExistsException("User already exists");
		}
		BeanUtils.copyProperties(userDto, user);
		String number = "+91 ".concat(userDto.getPhonenumber());
		user.setPhonenumber(number);
		user.setPassword(passwordEncoder.encode(userDto.getPassword()));

		AppUser appUser = new AppUser();
		appUser.setEmail(userDto.getEmail());
		appUser.setPassword(passwordEncoder.encode(userDto.getPassword()));
		appUser.setRole(Role.ROLE_USER);
		appUserRepository.save(appUser);
		User save = userRepository.save(user);
		BeanUtils.copyProperties(save, userDto);
		return userDto;

	}

	@Override
	public String registerDoctorModule(DoctorDto doctorDto) throws IOException {

		Doctor doctor = new Doctor();
		if (doctor.getDoctorEmail() == doctorDto.getDoctorEmail()) {
			throw new DoctorAlreadyExistsException("Email Already Exists Try to Login");
		}
		BeanUtils.copyProperties(doctorDto, doctor);
		String name = "Dr.".concat(doctorDto.getDoctorName());
		String phone = "+91 ".concat(doctorDto.getDoctorPhoneNumber());
		doctor.setDoctorName(name);
		doctor.setDoctorPhoneNumber(phone);
		doctor.setPassword(passwordEncoder.encode(doctorDto.getPassword()));

		// for security purpose
		AppUser appUser = new AppUser();
		appUser.setEmail(doctorDto.getDoctorEmail());
		appUser.setPassword(passwordEncoder.encode(doctorDto.getPassword()));
		appUser.setRole(Role.ROLE_DOCTOR);
		appUserRepository.save(appUser);

		doctor.setName(doctorDto.getFile().getOriginalFilename());
		doctor.setType(doctorDto.getFile().getContentType());
		doctor.setFile(doctorDto.getFile());
		doctor.setImageUrl(doctorDto.getImageUrl());

		Doctor save = doctorRepository.save(doctor);
		return "File Uploaded Successfully" + " " + doctorDto.getFile().getOriginalFilename();

	}

	@Override
	public Map<String, String> authenticateLogin(LoginDto loginDto) {

		Authentication authenticate = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(loginDto.getEmail(), loginDto.getPassword()));
		boolean isAuthenticated = false;

		if (authenticate.isAuthenticated()) {

			AppUser findByEmail = appUserRepository.findByEmail(loginDto.getEmail())
					.orElseThrow(() -> new AuthenticationServiceException("Authentication Failed"));
			System.err.println(findByEmail);
			
			Map<String, String> generateNewTokens = tokenGeneration.generateNewToken(findByEmail);
		
			return generateNewTokens;
	    
//			String generateRefreshToken = tokenGeneration.generateRefreshToken(findByEmail);
			
			
//			AuthResponse auth = new AuthResponse(generateNewToken, generateRefreshToken);
//			return auth;
		}
		throw new AuthenticationException("Authentication Failed ");
	}




}