package com.te.doctormgntsystem.exception;

@SuppressWarnings("serial")
public class PhoneNumberMissingException extends RuntimeException {

	public PhoneNumberMissingException(String message) {
		super(message);
	}
}
