package com.te.doctormgntsystem.entity;

public enum Role {

	ROLE_DOCTOR,
	ROLE_USER
}
