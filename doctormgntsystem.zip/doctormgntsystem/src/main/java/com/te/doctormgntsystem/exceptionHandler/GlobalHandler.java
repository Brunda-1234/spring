package com.te.doctormgntsystem.exceptionHandler;

import java.nio.file.AccessDeniedException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;

import com.te.doctormgntsystem.exception.AppointmentNotFoundException;
import com.te.doctormgntsystem.exception.BookingFailedException;
import com.te.doctormgntsystem.exception.DataNotFoundException;
import com.te.doctormgntsystem.exception.DoctorNotFoundException;
import com.te.doctormgntsystem.exception.DoctorNotUpdatedException;
import com.te.doctormgntsystem.exception.NotRegisteredException;
import com.te.doctormgntsystem.exception.PhoneNumberMissingException;
import com.te.doctormgntsystem.exception.ResourceNotFoundException;
import com.te.doctormgntsystem.exception.TimeSlotAvailabilityException;
import com.te.doctormgntsystem.response.Response;

import io.jsonwebtoken.ExpiredJwtException;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@ControllerAdvice
public class GlobalHandler extends ExceptionHandlerExceptionResolver{

	/*
	 * ExceptionHandlerExceptionResolver is a class in Spring Framework that handles exceptions thrown during the
	 *  execution of web requests. It is responsible for mapping exceptions to appropriate error responses.
	 */
	@ExceptionHandler(value = {NotRegisteredException.class})
	public ResponseEntity<Response> handler(NotRegisteredException e){
		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));		
	}
	
	@ExceptionHandler(value = {DoctorNotFoundException.class})
	public ResponseEntity<Response> handlerDoctorData(DoctorNotFoundException e){
		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));		
	}
	
	@ExceptionHandler(value = {BookingFailedException.class})
	public ResponseEntity<Response> handlerBooking(BookingFailedException e){
		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));			
	}
	
	@ExceptionHandler(value = {AppointmentNotFoundException.class})
	public ResponseEntity<Response> handlerAppointment(AppointmentNotFoundException e){
		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));			
	}
	
	@ExceptionHandler(value = {DataNotFoundException.class})
	public ResponseEntity<Response> handlerDoctorList(DataNotFoundException e){
		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));		
	}
	
	@ExceptionHandler(value = {DoctorNotUpdatedException.class})
	public ResponseEntity<Response> handler(DoctorNotUpdatedException e){
		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));		
	}
	
	@ExceptionHandler(value = {TimeSlotAvailabilityException.class})
	public ResponseEntity<Response> handler(TimeSlotAvailabilityException e){
		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));		
	}
	
	@ExceptionHandler(value = {PhoneNumberMissingException.class})
	public ResponseEntity<Response> phoneNumberHandler(PhoneNumberMissingException e){
		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));		
	}
	
//	@ExceptionHandler(value = {BadCredentialsException.class})
//	public ResponseEntity<Response> badCredentialsException(BadCredentialsException e){
//		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));		
//	}
	
	@ExceptionHandler(value = {Exception.class})
	public ResponseEntity<Response> exception(Exception e){
		return ResponseEntity.badRequest().body(new Response(true, e.getMessage(), HttpStatus.BAD_REQUEST, null));		
	}
	

	
	@ExceptionHandler(value = {ResourceNotFoundException.class})
	public ResponseEntity<Response> resourceHandler(ResourceNotFoundException exception){
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response(true,exception.getMessage(), HttpStatus.NOT_FOUND, null));
	}
    
	@ExceptionHandler(value = {ExpiredJwtException.class})
	public ResponseEntity<Response> jwtExpirationHandler(ExpiredJwtException exception){
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response(true,"The Given Token is Expired Please Provide the Refresh Token to Generate the New Access Token", HttpStatus.NOT_FOUND, null));
	}
	
	@ExceptionHandler(value = {NullPointerException.class})
	public ResponseEntity<Response> nullPointerExcepionHandler(NullPointerException exception){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response(true,"The Given Data Is Null", HttpStatus.NOT_FOUND, null));
	}
	
	

	
	
}
