package com.te.doctormgntsystem.exception;

public class TimeSlotAvailabilityException extends RuntimeException {

	public TimeSlotAvailabilityException (String message) {
		
		super(message);
	}
}
