package com.te.doctormgntsystem.exception;

public class DoctorNotUpdatedException extends RuntimeException {

	public DoctorNotUpdatedException(String message) {
		super(message);
	}
}
