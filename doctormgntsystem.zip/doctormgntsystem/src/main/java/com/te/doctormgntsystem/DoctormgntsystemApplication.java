package com.te.doctormgntsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctormgntsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctormgntsystemApplication.class, args);
	}

}
