package com.te.doctormgntsystem.jwtfilter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.te.doctormgntsystem.repository.AppUserRepository;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class ApplicationConfig {
	
	/*
	 * the ApplicationConfig class is responsible for configuring all the necessary beans required for security in the application.
	 */
	@Autowired
	private  AppUserRepository appUserRepositary;
	@Bean 
	public UserDetailsService userDetailsService() {
		System.err.println("Security userDetailsService");
		return username -> appUserRepositary.findByEmail(username)
				.orElseThrow(()-> new UsernameNotFoundException("user not found"));
		
	}
	 
	@Bean 
	public AuthenticationProvider authenticationProvider() {
		System.err.println("Security authenticationProvider");
		DaoAuthenticationProvider daoAuthenticationProvider=new DaoAuthenticationProvider();
		daoAuthenticationProvider.setUserDetailsService(userDetailsService());
		daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());
		return daoAuthenticationProvider;
		
	}
	
	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception{
		System.err.println("Security authenticationManager");
		return configuration.getAuthenticationManager();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	 
}
