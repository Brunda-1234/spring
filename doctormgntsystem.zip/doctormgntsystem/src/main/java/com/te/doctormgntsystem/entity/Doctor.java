package com.te.doctormgntsystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Builder
@Table(name = "Doctor_Table")
public class Doctor {
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Integer doctorId;
	    private String doctorName;
	    @Enumerated(EnumType.STRING)
		private DoctorSpecialization doctorSpecialization;
		private String doctorEmail ;
		private String doctorPhoneNumber;
		private Double avgRating;
		private String password;
		//image data
		private String name;
		private String type;
		private String imageUrl;
//		@Lob
//		private byte[] imageData;
		@Transient
		private MultipartFile file;
		
		
		
		
		@OneToMany(cascade = CascadeType.ALL,mappedBy = "doctor")
		private List<Appointment> appointments;
		
		@OneToMany(cascade = CascadeType.ALL,mappedBy = "doctor")
        private List<DoctorRating> doctorRating;
		

	}
