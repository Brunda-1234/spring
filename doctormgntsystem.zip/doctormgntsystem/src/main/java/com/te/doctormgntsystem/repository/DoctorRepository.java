package com.te.doctormgntsystem.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.te.doctormgntsystem.dto.DoctorDto;
import com.te.doctormgntsystem.entity.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Integer> {

	List<Doctor> findByDoctorPhoneNumberContaining(String doctorPhoneNumber);
	
//	List<Doctor> findByNameAndDoctorPhoneNumberContaining(String name,String doctorPhoneNumber);
	
	Optional<Doctor> findByName(String name);
	
	Doctor findByDoctorName(String doctorName);

	DoctorDto save(DoctorDto doctorDto);


	
	
}
