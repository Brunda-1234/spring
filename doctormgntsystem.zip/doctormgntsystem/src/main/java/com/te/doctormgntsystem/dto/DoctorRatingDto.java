package com.te.doctormgntsystem.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class DoctorRatingDto {

	private Double doctorRating;
	private Integer doctorId;
	private Integer id;

}
