package com.te.doctormgntsystem.dto;

import java.io.Serializable;

import javax.persistence.Lob;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class DoctorOneDto{ 

	private String doctorName;
	private String doctorEmail;
	private String doctorSpecialization;
	private String doctorPhoneNumber;
	private Double avgRating;
	private String name;
	private String type;
	
	private String imageUrl;
////	@Lob
//	private byte[]  imageData;
//	@Transient
//	private MultipartFile file;
}
